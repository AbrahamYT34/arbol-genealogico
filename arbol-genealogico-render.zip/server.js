const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuración crucial: permite recibir archivos grandes (fotos en Base64)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

// ══════════════════════════════════════════════════════════════════
// GUARDADO EN FIREBASE REALTIME DATABASE (gratis e indefinido)
// 
// Las rutas /api/familia y /api/mascotas siguen siendo EXACTAMENTE
// las mismas — tu index.html no necesita ningún cambio.
// ══════════════════════════════════════════════════════════════════
const FIREBASE_URL = process.env.FIREBASE_URL;
const FIREBASE_SECRET = process.env.FIREBASE_SECRET;

function urlFirebase(nodo) {
  return `${FIREBASE_URL}/${nodo}.json?auth=${FIREBASE_SECRET}`;
}

async function leerDeFirebase(nodo) {
  try {
    const r = await fetch(urlFirebase(nodo));
    if (!r.ok) throw new Error('Firebase respondió ' + r.status);
    const data = await r.json();
    return data || [];
  } catch (error) {
    console.error('Error leyendo de Firebase:', error);
    return [];
  }
}

async function guardarEnFirebase(nodo, data) {
  try {
    const r = await fetch(urlFirebase(nodo), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!r.ok) throw new Error('Firebase respondió ' + r.status);
  } catch (error) {
    console.error('Error guardando en Firebase:', error);
    throw error;
  }
}

// RUTA PARA LEER LOS DATOS (GET)
app.get('/api/familia', async (req, res) => {
  if (!FIREBASE_URL || !FIREBASE_SECRET) {
    console.warn('⚠️ Falta FIREBASE_URL / FIREBASE_SECRET');
    return res.json([]);
  }
  const data = await leerDeFirebase('familia');
  res.json(data);
});

// RUTA PARA GUARDAR LOS DATOS (POST)
app.post('/api/familia', async (req, res) => {
  try {
    await guardarEnFirebase('familia', req.body);
    res.json({ success: true, message: 'Datos guardados correctamente' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
});

// RUTA PARA LEER LAS MASCOTAS (GET)
app.get('/api/mascotas', async (req, res) => {
  if (!FIREBASE_URL || !FIREBASE_SECRET) {
    console.warn('⚠️ Falta FIREBASE_URL / FIREBASE_SECRET');
    return res.json([]);
  }
  const data = await leerDeFirebase('mascotas');
  res.json(data);
});

// RUTA PARA GUARDAR LAS MASCOTAS (POST)
app.post('/api/mascotas', async (req, res) => {
  try {
    await guardarEnFirebase('mascotas', req.body);
    res.json({ success: true, message: 'Mascotas guardadas correctamente' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log('====================================');
  console.log(`🌲 Servidor del Árbol Genealógico activo`);
  console.log(`🔗 Ingresa a: http://localhost:${PORT}`);
  if (!FIREBASE_URL || !FIREBASE_SECRET) {
    console.log('⚠️  Falta configurar FIREBASE_URL y FIREBASE_SECRET');
  }
  console.log('====================================');
});
